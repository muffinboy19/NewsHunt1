package com.example.newsapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Home_Screen : AppCompatActivity() {
    private val dataArray = listOf(Icon(R.drawable.war),Icon(R.drawable.goverment),Icon(R.drawable.education),Icon(
        R.drawable.health_care),Icon(R.drawable.enviorment),Icon(R.drawable.economy),Icon(R.drawable.buisness__2_),Icon(R.drawable.fashion),Icon(R.drawable.entertainment),Icon(R.drawable.sports))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_screen)
        val categori = findViewById<RecyclerView>(R.id.rc_categories)
        val latest_news = findViewById<RecyclerView>(R.id.latestitem)
        categori.layoutManager=LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
        categori.adapter=IconAdapter(dataArray)



    }
}