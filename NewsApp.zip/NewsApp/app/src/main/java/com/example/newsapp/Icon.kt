package com.example.newsapp

data class Icon(val resouceId:Int)

