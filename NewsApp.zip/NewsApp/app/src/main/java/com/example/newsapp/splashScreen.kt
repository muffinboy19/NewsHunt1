package com.example.newsapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class splashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)



        val splashScreenDurationMs = 2000 // 2 seconds (adjust as needed)
        Handler().postDelayed({
            // Start the main activity
            val intent = Intent(this, Home_Screen::class.java)
            startActivity(intent)

            // Finish the splash screen activity so that the user cannot go back to it
            finish()
        }, splashScreenDurationMs.toLong())
    }
}