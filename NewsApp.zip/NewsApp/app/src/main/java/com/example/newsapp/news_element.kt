package com.example.newsapp

data class news_element()
